#!/bin/sh
aws ec2 describe-instance-attribute --instance-id <EC2_instance_id> --attribute <mention_below_any_attribute> --region <your_region>