#!/bin/sh
echo '{"a1":{"b1":{"c1":"x1"}}}' | jq '.. | .c1? | select(. != null)'