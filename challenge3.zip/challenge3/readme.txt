Install jq package in any Ubuntu server using below command.

sudo apt-get install jq

Run below command:

echo '{"a1":{"b1":{"c1":"x1"}}}'| jq '.. | .c1? | select(. != null)'